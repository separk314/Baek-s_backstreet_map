package umc.server.baeksstreetmapserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaeksStreetMapServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
