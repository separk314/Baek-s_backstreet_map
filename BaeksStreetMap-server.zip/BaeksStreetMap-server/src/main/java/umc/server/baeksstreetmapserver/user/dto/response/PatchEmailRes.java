package umc.server.baeksstreetmapserver.user.dto.response;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class PatchEmailRes {

	private String result;

}
