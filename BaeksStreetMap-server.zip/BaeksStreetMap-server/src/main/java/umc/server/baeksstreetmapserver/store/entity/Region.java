package umc.server.baeksstreetmapserver.store.entity;

public enum Region {
	SEOUL, DAEJEON, DAEGU, BUSAN, GYEONGGI, INCHEON, GANGWON, GYEONGSANG, JEOLLA, CHUNGCHEONG, JEJU;
}
