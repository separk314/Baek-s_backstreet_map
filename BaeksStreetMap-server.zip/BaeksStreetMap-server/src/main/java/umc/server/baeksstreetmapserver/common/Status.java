package umc.server.baeksstreetmapserver.common;

public enum Status {
	ACTIVE, INACTIVE;
}
